#include "MenusPack.h"

int main() {
	MenusPack MenuCreator;
	MenuCreator.DrawHelloScreen();
	MenuCreator.MainMenu();
	return 0;
}